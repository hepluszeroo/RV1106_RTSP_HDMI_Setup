#!/bin/sh

cp -ap ./lib/* /oem/usr/lib/
mkdir -p /oem/usr/bin/nrkipc/log
touch /oem/usr/bin/nrkipc/log/nrkipc.log
cp bin/nrkipc /oem/usr/bin/nrkipc/
chmod +x /oem/usr/bin/nrkipc/nrkipc
cp configs/nrkipc.conf /oem/usr/bin/nrkipc/
cp -rf htdocs /oem/usr/bin/nrkipc/
cp -rf ./RkLunch.sh /oem/usr/bin/
echo "install ok!"
